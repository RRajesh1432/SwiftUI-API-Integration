import SwiftUI

struct LoginView: View {

    @State private var viewModel = ScreenViewModel()

    var body: some View {

        NavigationStack {

            Form {

                Section("Login") {

                    HStack{
                        TextField(
                            "Phone number",
                            text: $viewModel.phoneNumber
                        )
                        .keyboardType(.phonePad)
                        .buttonStyle(.borderedProminent)
                        

                        Button("Send SMS Code") {
                            viewModel.sendSMSCode()
                        }
                        .disabled(viewModel.isLoading)

                    }
                    
                    HStack{
                        TextField(
                            "Enter OTP",
                            text: $viewModel.otp
                        )
                        .keyboardType(.numberPad)

                        Button("Verify SMS Code") {
                            viewModel.verifySMSCode()
                        }
                        .disabled(viewModel.isLoading)

                    }
                    
                }
                
                VStack(alignment: .center){
                    Button("Sign In") {
                        viewModel.signIn()
                    }
                    .disabled(viewModel.isLoading)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(.blue)
                    .foregroundStyle(.white)
                    .cornerRadius(16)
                    .fontWeight(.bold)
                }


                if viewModel.isLoading {
                    
                        ProgressView("Please wait...")
                    
                }else if !viewModel.errorMessage.isEmpty {
                    
                    Section("Error") {
                        Text(viewModel.errorMessage)
                            .foregroundStyle(.red)
                    }
                }

//                if !viewModel.message.isEmpty {
//                    Section("Response") {
//                        Text(viewModel.message)
//                            .font(.caption)
//                            .textSelection(.enabled)
//                    }
//                }

                
            }
            .navigationTitle("Login")
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(
                isPresented: $viewModel.isShowingHome
            ) {
                HomeView()
            }
        }
    }
    
   
}
