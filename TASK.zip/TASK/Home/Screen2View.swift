import SwiftUI

struct HomeView: View {

    @State private var viewModel = Screen2ViewModel()

    var body: some View {

        VStack(spacing: 0) {

            Form {

                if viewModel.isLoading {
                        ProgressView("Loading...")
                }else if !viewModel.errorMessage.isEmpty {
                    Section("Error") {
                        Text(viewModel.errorMessage)
                            .foregroundStyle(.red)
                    }
                }
                
                if viewModel.displayResponse == "Event"{
                    seheduleEventView
                }else {
                    getTeamView
                }
                
            }

            HStack(spacing: 12) {

                Button("Scheduled Events") {
                    
                    viewModel.displayResponse = "Event"
                    viewModel.getScheduledEvents()
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(Color.blue)
                .foregroundStyle(.white)
                .cornerRadius(10)
                .disabled(viewModel.isLoading)

                Button("Teams List") {
                    viewModel.displayResponse = "Teams"
                    viewModel.getTeams()
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(Color.green)
                .foregroundStyle(.white)
                .cornerRadius(10)
                .disabled(viewModel.isLoading)
            }
            .padding()
        }
        .navigationTitle("Home")
        .task {
            viewModel.loadHomeData()
        }
    }
    
    var seheduleEventView : some View {
        
        Section("Scheduled Events") {

            if viewModel.eventsResponse.isEmpty {

                Text("No events loaded.")
                    .foregroundStyle(.secondary)

            } else {
                
                ForEach(viewModel.eventsResponse.indices, id: \.self) { index in

                    let event = viewModel.eventsResponse[index]

                    VStack(alignment: .leading, spacing: 8) {

                        Text("Event \(index + 1)")
                            .font(.headline)

                        Text(String(describing: event))
                            .font(.subheadline)
                            .textSelection(.enabled)
                    }
                    .padding(.vertical, 6)
                }
            }
        }
    }
    
    var getTeamView : some View {
        
        Section("Teams List") {

            if viewModel.teamsResponse.isEmpty {

                Text("No teams loaded.")
                    .foregroundStyle(.secondary)

            } else {

                ForEach(viewModel.teamsResponse, id: \.id) { team in

                    VStack(alignment: .leading, spacing: 6) {

                        Text("ID: \(team.id)")
                            .font(.headline)

                        Text("Name: \(team.name)")

                        Text("Team Type: \(team.teamType)")

                        Text("Member Count: \(team.memberCount)")
                    }
                    .padding(.vertical, 5)
                }
            }
        }
    }
}
